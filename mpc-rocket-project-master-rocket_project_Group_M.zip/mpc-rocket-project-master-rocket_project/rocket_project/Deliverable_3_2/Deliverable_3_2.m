addpath(fullfile('..', 'src'));

%close all
%clear all
%clc

%% TODO: This file should produce all the plots for the deliverable
Ts = 1/20; % Sample time
H = 5; % Horizon length in seconds
T_sym = 8.0; % Simulation time in seconds
rocket = Rocket(Ts);

[xs, us] = rocket.trim();
sys = rocket.linearize(xs, us);
[sys_x, sys_y, sys_z, sys_roll] = rocket.decompose(sys, xs, us);


% Design the MPC controllers for the 4 subsystems
mpc_x = MpcControl_x(sys_x, Ts, H);
mpc_y = MpcControl_y(sys_y, Ts, H);
mpc_z = MpcControl_z(sys_z, Ts, H);
mpc_roll = MpcControl_roll(sys_roll, Ts, H);


%% X controller closed and open loop
x0 = [0, 0 ,0 ,0]';
x_ref = -4 ;
[T, X_sub, U_sub] = rocket.simulate_f(sys_x, x0, T_sym, @mpc_x.get_u, x_ref);
ph = rocket.plotvis_sub(T, X_sub, U_sub, sys_x, xs, us);
sgtitle("Controller of X closed loop");
[ux, T_optx, X_optx, U_optx] = mpc_x.get_u(x0, x_ref);
U_optx(:,end+1) = nan;
phx = rocket.plotvis_sub(T_optx, X_optx, U_optx, sys_x, xs, us);
sgtitle("Controller of X open loop");
%% Y controller closed and open loop
x0 = [0, 0 ,0 ,0]'; 
x_ref = -4 ;
[T, X_sub, U_sub] = rocket.simulate_f(sys_y, x0, T_sym, @mpc_y.get_u, x_ref);
ph = rocket.plotvis_sub(T, X_sub, U_sub, sys_y, xs, us);
sgtitle("Controller of Y closed loop");
[uy, T_opty, X_opty, U_opty] = mpc_y.get_u(x0, x_ref);
U_opty(:,end+1) = nan;
phy = rocket.plotvis_sub(T_opty, X_opty, U_opty, sys_y, xs, us);
sgtitle("Controller of Y open loop");

%% Z controller closed and open loop
x0 = [0, 0]';
x_ref = -4 ;
[T, X_sub, U_sub] = rocket.simulate_f(sys_z, x0, T_sym, @mpc_z.get_u, x_ref);
ph = rocket.plotvis_sub(T, X_sub, U_sub, sys_z, xs, us);
sgtitle("Controller of Z closed loop");
[uz, T_optz, X_optz, U_optz] = mpc_z.get_u(x0, x_ref);
U_optz(:,end+1) = nan;
phz = rocket.plotvis_sub(T_optz, X_optz, U_optz, sys_z, xs, us);
sgtitle("Controller of Z open loop");

%% Roll controller closed and open loop
x0 = [0, 0]'; 
x_ref = 7*pi/36;
[T, X_sub, U_sub] = rocket.simulate_f(sys_roll, x0, T_sym, @mpc_roll.get_u, x_ref);
ph = rocket.plotvis_sub(T, X_sub, U_sub, sys_roll, xs, us);
sgtitle("Controller of roll closed loop");
[ur, T_optr, X_optr, U_optr] = mpc_roll.get_u(x0, x_ref);
U_optr(:,end+1) = nan;
phr = rocket.plotvis_sub(T_optr, X_optr, U_optr, sys_roll, xs, us);
sgtitle("Controller of roll open loop");
